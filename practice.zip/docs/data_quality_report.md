# Week 3 Data Quality Report

Keep this to one page. A supervisor should be able to read it in two minutes
and know what they may do with the file.

## 1. What I examined

- File name: shift_log_samiullah5ee-sys.csv
- SHA-256 fingerprint: c1200f12acd1397e2ea39eacadd3df565913df1191fac0e1d6655d65d3e7d4f8
- Rows / columns: 73 / 8 
- One row represents: One hourly production record for a single production line during a specific timestamp and shift.
- The business key is: timestamp + line_id — each production line should have only one record for each timestamp. If the same line can have multiple records per timestamp across different shifts, include shift in the business key.
- Reviewed by / date: Muhammad Samiullah / 10-10-2026

## 2. What I found before running the validator

Fill this in **during Step 3 of the notebook**, before you compare against the
checks. Do not go back and improve it afterwards; the gap is the point.

| # | Record (line and hour) | What I noticed |
|---|---|---|
| 1 | Line_A — 2026-01-12 07:00 | Motor temperature is 116.9°C, which is unusually high |
| 2 | Line_B — 2026-01-12 11:00 | Downtime is 90.2 minutes, which exceeds one hour |
| 3 | Line_C — 2026-01-12 15:00 | The same record appears twice with identical values |

## 3. What the checks found

One row per distinct problem. If one fault trips two checks, say so rather than
counting it twice.

| Check | CSV line(s) | Observation (no speculation) | Impossible or surprising? | What should happen next | Who owns it |
|---|---|---|---|---|---|
| Check | CSV line(s) | Observation (no speculation) | Impossible or surprising? | What should happen next | Who owns it |
|---|---|---|---|---|---|
| Invalid timestamps | None | All timestamps parsed successfully. | No issue found | No action required. | Data engineer |
| Missing values | 17 | `downtime_min` is missing for Line_C at 2026-01-12 10:00. | Data quality issue | Check the original production log and recover the value if possible. | Production operator |
| Line-hour coverage and label consistency |  | Line_A has 24 distinct hours, Line_B has 24, Line_C has 23, and `line_c` has 1. Total unique line-hour combinations: 72. | Data quality issue | Verify whether `line_c` should be `Line_C` and investigate missing line-hour combinations. | Data engineer |
| Shift mismatch | 13 | Line_B at 2026-01-12 09:00 is labelled Night, but the expected shift is Day. | Contract violation | Verify the shift label against the original production log. | Shift supervisor |
| High motor temperature | 6 | Line_A at 2026-01-12 07:00 has a motor temperature of 116.9°C. | Surprising but possible | Verify the sensor reading and equipment operating limits. | Maintenance technician |
| Downtime above 60 minutes | 19 | Line_B at 2026-01-12 11:00 has 90.2 minutes of downtime. | Surprising but possible | Verify the downtime measurement definition and original production log. | Production supervisor |
| Exact duplicate records | 32, 75 | Line_C at 2026-01-12 15:00 appears twice with identical values across all columns. This triggers both the exact-duplicate check and the repeated line-hour check; it is one distinct problem. | Data quality issue | Verify the source and remove the duplicate only after confirmation. | Data engineer |
| Repeated line-hour with different values | None | No repeated timestamp and line_id combination with different values was found. | No issue found | No action required. | Data engineer |
| Impossible numeric values | None | No negative production, downtime, energy, or rejected units were found, and rejected units did not exceed units produced. | No issue found by these checks | Retain these validation checks. | Data engineer |

## 4. The gap

- Found by the checks, missed by me:
- Found by me, covered by no check:
- The check I added or would add as a result:

## 5. The judgement call

The high motor temperature reading is unusual, not impossible.

- Three explanations, one of which is not a fault:
- The single piece of evidence that would separate them:
- Who holds it:

## 6. What this file can and cannot support

Connect this back to the Week 2 decision boundary in two or three sentences.
Name one calculation that is still safe and one that is not, and say why the
difference follows from the specific faults you found.
